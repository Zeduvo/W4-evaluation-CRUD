<?php

/*
 * Ce fichier contient toutes les constantes de configuration de l'application 
 * 
 */

define ('DBH','mysql:dbname=message;host=localhost');
define ('USER','admin');
define ('PASSWORD', 'admin');
define ('DATABASE', 'todo');
