<?php

class Todo
{
    public $id; 
    public $title;
    public $category;
    public $description;

}
?>